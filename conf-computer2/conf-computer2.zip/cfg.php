<?php 
	
	$host = 'localhost'; // адрес сервера 
	$database = 'cfgpc'; // имя базы данных
	$user = 'root'; // имя пользователя
	$password = 'root'; // пароль

	$connect = mysqli_connect($host, $user, $password, $database);



	$bootstrap = '<link rel="stylesheet" href="https://
	 			maxcdn.bootstrаpcdn.com/bootstrap/4.0.0
	 			/css/bootstrаp.min.css.js" i
	 			ntegrity="sha384-Gn5384xqQ1aoWXA+058RXP
	 			xPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6
	 			JXm" crossorigin="anonymous">';




 
